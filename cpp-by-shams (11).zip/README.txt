C++ by Shams — Website files

Files included:
- index.html : main website file

How to open locally (in Google Chrome):
1. Download and unzip the package.
2. Open the folder and double-click 'index.html' -> it will open in your default browser.
   Or: Right-click index.html -> Open with -> Google Chrome.

How to publish on GitHub Pages:
1. Create a GitHub repository (e.g., cpp-by-shams).
2. Upload index.html to the repository (Add file -> Upload files -> Commit changes).
3. Go to Settings -> Pages -> Branch: main, Folder: /(root) -> Save.
4. After a minute the site will be live at: https://yourusername.github.io/cpp-by-shams/

If you want, tell me:
- Your GitHub username so I can update the README links.
- Your email to put on the page.
